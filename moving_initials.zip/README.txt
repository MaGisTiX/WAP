různá změna tloušťky podle pohybu myši
